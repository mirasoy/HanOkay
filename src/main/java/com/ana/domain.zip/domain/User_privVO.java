package com.ana.domain;

import lombok.Data;

@Data
public class User_privVO {
	private String PRIVG_ID;
	private String USER_NUM;

}
