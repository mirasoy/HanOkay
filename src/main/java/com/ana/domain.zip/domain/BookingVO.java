package com.ana.domain;

import java.util.Date;

import lombok.Data;

@Data
public class BookingVO {
   private String book_int;
   private String user_int;
   private String rom_int;
   private Date book_date;
   private Date checkin_date;
   private Date chekout_date;
   private int staydays;
   private int guest;
   private int book_price;
   private int deposit;
   private char canceled;
   private String expected_arr;
   private char smoking;
   private String request;
   private String real_arr;
}