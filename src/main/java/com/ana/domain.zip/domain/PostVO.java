package com.ana.domain;

import java.util.Date;

import lombok.Data;

@Data
public class PostVO {
	private String BRD_CODE;
	private String USER_NUM;
	private String PST_NUM;
	private String P_TITLE;
	private String P_CONTENT;
	private Date P_REGDATE;
	private Date P_UPDATEDATE;
}
