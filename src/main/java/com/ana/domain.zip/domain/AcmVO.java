package com.ana.domain;

import java.util.Date;

import lombok.Data;

@Data
public class AcmVO {
	
	private String ACM_NUM;
	private String ACM_NAME;
	private String ACM_CITY;
	private String ACM_DISTR;
	private String ACM_DETAILADDR;
	private Long REP_PHONE;
	private Long BIZ_REGNUM;
	private String CHECKIN_TIME;
	private String CHECKOUT_TIME;
	private Date ACM_REGDATE;
	private Date ACM_UPDATEDATE;
	private Long PHONE2;
	private Long ACM_FAX;
	private String ACM_EMAIL;
	private String ACM_DESC;
}
