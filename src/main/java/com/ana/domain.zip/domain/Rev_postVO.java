package com.ana.domain;

import lombok.Data;

@Data
public class Rev_postVO {
	private String BRD_CODE;
	private String REV_PURL;
	private int STISF;
	private String BOOK_NUM;
}
