package com.ana.domain;

import java.util.Date;
import lombok.Data;

@Data
public class RoomVO {
   
   private String ROM_NUM;
   private String ACM_NUM;
   private String ROOM_NAME;
   private int CAPACITY;
   private String BED_TYPE;
   private int BED_CNT;
   private int ROM_SIZE;
   private Date START_DATE;
   private Date END_DATE;
   private int PRICE;
   private String ROM_PURL;
   private String ROM_LOCAINFO;

}
