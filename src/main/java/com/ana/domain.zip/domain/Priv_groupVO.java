package com.ana.domain;

import lombok.Data;

@Data
public class Priv_groupVO {
	private String PRIVG_ID;
	private String PRIVG_TITLE;
}
